CREATE DATABASE crime_database;
USE crime_database;

CREATE TABLE CrimeData (
    CrimeID INT AUTO_INCREMENT,
    CrimeType VARCHAR(255),
    District VARCHAR(255),
    OccurrenceDate VARCHAR(255),  
    Details TEXT,
    PRIMARY KEY (CrimeID)
);

SHOW VARIABLES LIKE 'secure_file_priv';


LOAD DATA INFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\Crime Data.csv'
INTO TABLE CrimeData
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(CrimeID, CrimeType, District, OccurrenceDate, Details);

-- Top 3 districts with the highest number of crimes in the last year

SELECT District, COUNT(*) as CrimeCount
FROM CrimeDataRefined
WHERE OccurrenceDate >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY District
ORDER BY CrimeCount DESC
LIMIT 3;

-- Rank crime types by occurrences within each district using window functions

SELECT District, CrimeType, COUNT(*) as OccurrenceCount,
       RANK() OVER (PARTITION BY District ORDER BY COUNT(*) DESC) as Ranke
FROM CrimeDataRefined
GROUP BY District, CrimeType
ORDER BY District, Ranke;

-- Calculate month-over-month percentage change in overall crime rates for the past year

WITH MonthlyCrime AS (
    SELECT DATE_FORMAT(OccurrenceDate, '%Y-%m') as Month, COUNT(*) as CrimeCount
    FROM CrimeDataRefined
    WHERE OccurrenceDate >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
    GROUP BY DATE_FORMAT(OccurrenceDate, '%Y-%m')
)
SELECT Month,
       CrimeCount,
       LAG(CrimeCount) OVER (ORDER BY Month) as PreviousMonthCrimeCount,
       ROUND(((CrimeCount - LAG(CrimeCount) OVER (ORDER BY Month)) / LAG(CrimeCount) OVER (ORDER BY Month)) * 100, 2) as MoMChange
FROM MonthlyCrime;

-- Extract data on burglary crimes, sorting them by frequency and highlighting seasonal trends

SELECT DATE_FORMAT(OccurrenceDate, '%Y-%m') as Month, COUNT(*) as BurglaryCount
FROM CrimeDataRefined
WHERE CrimeType = 'Burglary'
GROUP BY DATE_FORMAT(OccurrenceDate, '%Y-%m')
ORDER BY BurglaryCount DESC;

